def zipped(*args):
    return list(args)


def grid(*args):
    return tuple(args)
