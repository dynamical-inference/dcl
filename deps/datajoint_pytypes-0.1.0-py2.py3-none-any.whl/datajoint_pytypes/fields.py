"""Python definition of datajoint's types

Reference: https://docs.datajoint.org/python/definition/06-Datatypes.html
Documentation copied from datajoint docs.
"""

import dataclasses
from typing import Tuple

import datajoint as dj


@dataclasses.dataclass
class Field:

    comment: str = ""
    default: str = None
    primary_key: bool = False

    def __post_init__(self):
        self.comment = self.comment.strip()

    def name(self, key, prefix="{key} {default}: {self}"):
        value = prefix.format(
            key=key,
            self=self,
            default=f" = {self.default}" if self.default is not None else "",
        )
        if len(self.comment) > 0:
            value += f"\t# {self.comment}"
        return value


@dataclasses.dataclass
class TableField(Field):

    table: dj.Table = None

    def __str__(self):
        if self.table is None:
            raise ValueError(
                "Missing argument when instantiating the TableField")
        return self.table.__name__.split(".")[-1]

    def name(self, key):
        return super().name(None, prefix="-> {self}")


@dataclasses.dataclass
class PartTableField(TableField):

    main: dj.Table = None

    def __str__(self):
        if self.table is None or self.main is None:
            raise ValueError(
                "Missing argument when instantiating the TableField")
        main = self.main.__name__.split('.')[-1]
        part = self.table.__name__.split('.')[-1]
        return f'{main}.{part}'


@dataclasses.dataclass
class TinyIntField(Field):
    """An 8-bit integer number, ranging from -128 to 127."""

    def __str__(self):
        return f"tinyint"


@dataclasses.dataclass
class UnsignedTinyIntField(Field):
    """An 8-bit positive integer number, ranging from 0 to 255."""

    def __str__(self):
        return f"tinyint unsigned"


@dataclasses.dataclass
class SmallIntField(Field):
    """A 16-bit integer number, ranging from -32,768 to 32,767."""

    def __str__(self):
        return f"smallint"


@dataclasses.dataclass
class UnsignedSmallIntField(Field):
    """a 16-bit positive integer, ranging from 0 to 65,535."""

    def __str__(self):
        return f"smallint unsigned"


@dataclasses.dataclass
class IntField(Field):
    """a 32-bit integer number, ranging from -2,147,483,648 to 2,147,483,647."""

    def __str__(self):
        return f"int"


@dataclasses.dataclass
class UnsignedIntField(Field):
    """a 32-bit positive integer, ranging from 0 to 4,294,967,295."""

    def __str__(self):
        return f"int unsigned"


@dataclasses.dataclass
class EnumField(Field):
    """one of several explicitly enumerated values specified as strings.

    Use this datatype instead of text strings to avoid spelling variations and to save storage space.
    For example, the datatype for an anesthesia attribute could be enum("urethane", "isoflurane", "fentanyl").
    Do not use enums in primary keys due to the difficulty of changing their definitions consistently in multiple tables.
    """

    enum: Tuple[str] = dataclasses.field(default_factory=tuple)

    def __str__(self):
        if len(self.enum) == 0:
            raise ValueError("Need at least one value to enumerate")
        elements = ",".join(f"'{item}'" for item in self.enum)
        return f"enum({elements})"


@dataclasses.dataclass
class DateField(Field):
    """date as 'YYYY-MM-DD'."""

    def __str__(self):
        return f"date"


@dataclasses.dataclass
class TimeField(Field):
    """time as 'HH:MM:SS'."""

    def __str__(self):
        return f"time"


@dataclasses.dataclass
class DateTimeField(Field):
    """Date and time to the second as 'YYYY-MM-DD HH:MM:SS'"""

    def __str__(self):
        return f"datetime"


@dataclasses.dataclass
class TimestampField(Field):
    """Date and time to the second as 'YYYY-MM-DD HH:MM:SS'. The default value may be set to CURRENT_TIMESTAMP.
    Unlike datetime, a timestamp value will be adjusted to the local time zone."""

    def __str__(self):
        return "timestamp"


@dataclasses.dataclass
class CharField(Field):
    """A character string up to N characters (but always takes the entire N bytes to store)."""

    length: int = 0

    def __str__(self):
        return f"char({self.length})"


@dataclasses.dataclass
class VarcharField(Field):
    """A text string of arbitrary length up to N characters
    that takes M+1 or M+2 bytes of storage, where M is the actual length of each stored string.
    """

    length: int = 0

    def __str__(self):
        return f"varchar({self.length})"


@dataclasses.dataclass
class FloatField(Field):
    """float: a single-precision floating-point number. Takes 4 bytes. Single precision is sufficient for many measurements."""

    def __str__(self):
        return "float"


@dataclasses.dataclass
class DoubleField(Field):
    """a double-precision floating-point number. Takes 8 bytes. Because equality comparisons are error-prone, neither float nor double should be used in primary keys."""

    def __str__(self):
        return "double"


@dataclasses.dataclass
class DecimalField(Field):
    """A fixed-point number with N total decimal digits and F fractional digits.
    This datatype is well suited to represent numbers whose magnitude is well defined
    and does not warrant the use of floating-point representation or requires precise
    decimal representations (e.g. dollars and cents). Because of its well-defined precision,
    decimal values can be used in equality comparison and be included in primary keys.
    """

    total_decimal_digits: int = 1
    fractional_digits: int = 1

    def __str__(self):
        return f"decimal({self.total_decimal_digits}, {self.fractional_digits})"


@dataclasses.dataclass
class LongDecimalField(Field):
    """A fixed-point number with N total decimal digits and F fractional digits.
    This datatype is well suited to represent numbers whose magnitude is well defined
    and does not warrant the use of floating-point representation or requires precise
    decimal representations (e.g. dollars and cents). Because of its well-defined precision,
    decimal values can be used in equality comparison and be included in primary keys.
    """

    total_decimal_digits: int = 32
    fractional_digits: int = 24

    def __str__(self):
        return f"decimal({self.total_decimal_digits}, {self.fractional_digits})"


@dataclasses.dataclass
class LongblobField(Field):
    """Arbitrary numeric array (e.g. matrix, image, structure), up to 4 GiB in size.

    Numeric arrays are compatible between MATLAB and Python (NumPy).
    The longblob and other blob datatypes can be configured to store data
    externally by using the blob@store syntax.
    """

    data_store: str = None

    def __str__(self):
        if self.data_store is None:
            return "longblob"
        else:
            return f"longblob@{self.data_store}"
