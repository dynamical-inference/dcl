import datajoint as dj

def connect_to_database():
    """Connects to the database using the credentials in the login.py file"""
    dj.config["database.host"] = "128.178.84.27:3306"
    dj.config["database.user"] = "root"
    dj.config["database.password"] = "xcebra2023"
    dj.config["enable_python_native_blobs"] = True
    dj.conn()
